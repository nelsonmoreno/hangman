'use strict';

/**
 * @ngdoc function
 * @name warApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the warApp
 */
angular.module('warApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];

	var wordArray;
	var wordArrayLength;
    
    $scope.word="";
    $scope.chars=[];
    $scope.hangmanWord="";
    $scope.user={'attempts':0, 'games':{}};
    $scope.maxAttempts = 10;

    $scope.words=['uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince'];
 
    $scope.randWords = function (){
    	return $scope.words[Math.floor(Math.random() * $scope.words.length)];
    }
    
    $scope.reset = function (){
    	$scope.word = $scope.randWords();    	
    	 wordArray = $scope.word.split('');
    	 wordArrayLength = wordArray.length;
    	for (var i = 0; i < wordArrayLength; i++) {
    		$scope.chars.push ({'char':wordArray[i], 'visible':false});
    	    //Do something
    	}
    	console.log('word...! ' + $scope.word);
    	//score...
    }
    
    $scope.tryhang = function(char){
    	if(null==$scope.word||$scope.word.trim().length<1){
    		$scope.reset();
    	}
    	if($scope.hangmanWord.indexOf(char)>-1){
    		//--
    		$scope.user.attempts = $scope.user.attempts + 1;
    		console.log('used bad! ' + $scope.hangmanWord);
    	}else{
    		if($scope.word.indexOf(char)>-1){
    			$scope.word = $scope.word.replace(eval('/'+char+'/gi'), '');
    			
    			for(var i = 0; i < $scope.chars.length; i++){
    				if($scope.chars[i].char.toUpperCase()===char.toUpperCase()){
    					$scope.chars[i].visible = true;
    				}
    			}
        		console.log('good!' + $scope.word);
    		}else{
        		$scope.user.attempts = $scope.user.attempts + 1;
        		console.log('bad! ' + char + ' is not in ' + $scope.word + ' vs ' + $scope.hangmanWord);
    		}
    		$scope.hangmanWord = $scope.hangmanWord  + char;
    	}
    	
    	if($scope.maxAttempts <= $scope.user.attempts){
    		console.log('Game over!');
    	}
    	
    	if($scope.word.length===0){
    		console.log('Winner!');    		
    	}
    }
    
    $scope.keypress = function(keyEvent) {
    	var char = String.fromCharCode(keyEvent.keyCode)
    	$scope.tryhang(char);
    };

    
	var coin,
	coinImage,
	canvas;					

	$scope.gameLoop = function () {

		window.requestAnimationFrame($scope.gameLoop);

		switch($scope.user.attempts) {
		    case 1:
		    	coin.draw(5, 5, 256, 145, 0, 220, 256, 145);
		        break;
		    case 2:
		        coin.draw( 90, 52, 100, 305, 0, 0, 100, 310);
		        break;
		    case 3:
		        coin.draw(5, 52, 75, 71, 97, 1, 75, 71);
		        break;
		    case 4:
		        coin.draw(266, 5, 84, 88, 165, 0, 84, 88);
		        break;
		    case 5:
		        coin.draw( 197, 238, 63, 66, 130, 61, 63, 66);
		        break;
		    case 6:
		        coin.draw(266, 103, 79, 55, 119, 116, 79, 55);
		        break;
		    case 7:
		        coin.draw(5, 168, 39, 70, 173, 80, 39, 70);
		        break;
		    case 8:
		        coin.draw(261, 168, 40, 60, 105, 82, 40, 60);
		        break;
		    case 9:
		        coin.draw(197, 52, 59, 68, 160, 150, 59, 68);
		        break;
		    case 10:
		        coin.draw(197, 130, 54, 64, 104, 150, 54, 64);
		        break;		        
		    default:
		       ;
		}		
		/*coin.drawBase();
		coin.drawPoste();
		coin.drawViga();
		coin.drawHead();
		coin.drawBody();
		coin.drawPants();
		coin.drawRHand();
		coin.drawLHand();
		coin.drawRFeet();
		coin.drawLFeet();*/
	}

function sprite (options) {

	var that = {},
		frameIndex = 0,
		tickCount = 0,
		ticksPerFrame = options.ticksPerFrame || 0,
		numberOfFrames = options.numberOfFrames || 1;
	
	that.context = options.context;
	that.width = options.width;
	that.height = options.height;
	that.image = options.image;
	
	that.draw = function (sx, sy, swidth, sheight, x, y, width, height) {
		
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   sx,
		   sy,
		   swidth,
		   sheight,
		   x,
		   y,
		   width,
		   height);
	};	
	/*
	that.drawPoste = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   90,
		   52,
		   100,
		   that.height,
		   0,
		   0,
		   100,
		   327);
	};
	
	that.drawHead = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   266,
		   5,
		   84,
		   88,
		   165,
		   0,
		   84,
		   88);
	};	

	that.drawBody = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   197,
		   238,
		   63,
		   66,
		   130,
		   61,
		   63,
		   66);
	};

	that.drawPants = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   266,
		   103,
		   79,
		   55,
		   119,
		   116,
		   79,
		   55);
	};

	that.drawRHand = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   5,
		   168,
		   39,
		   70,
		   173,
		   80,
		   39,
		   70);
	};
	
	that.drawLHand = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   261,
		   168,
		   40,
		   60,
		   105,
		   82,
		   40,
		   60);
	};		
	
	that.drawRFeet = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   197,
		   52,
		   59,
		   68,
		   160,
		   150,
		   59,
		   68);
	};		

	that.drawLFeet = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   197,
		   130,
		   54,
		   64,
		   104,
		   150,
		   54,
		   64);
	};			

	that.drawViga = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   5,
		   52,
		   75,
		   71,
		   97,
		   1,
		   75,
		   71);
	};		
	
	
	that.drawBase = function () {
	
		// Clear the canvas
		//that.context.clearRect(0, 0, that.width, that.height);
	  
		// Draw the animation
		that.context.drawImage(
		   that.image,
		   5,
		   5,
		   256,
		   145,
		   0,
		   220,
		   256,
		   145);
	};		*/
	
	return that;
}

// Get canvas
canvas = document.getElementById("coinAnimation");
canvas.width = 260;
canvas.height = 260;

// Create sprite sheet
coinImage = new Image();	

// Create sprite
coin = sprite({
	context: canvas.getContext("2d"),
	width: 346,
	height: 320,
	image: coinImage,
	numberOfFrames: 10,
	ticksPerFrame: 4
});

// Load sprite sheet
coinImage.addEventListener("load", $scope.gameLoop);
coinImage.src = "images/spritesheetww.png";    
    
    
  });
