
(function () {
			
	var coin,
		coinImage,
		canvas;					

	function gameLoop () {
	
	  window.requestAnimationFrame(gameLoop);

	  //coin.update();
		coin.drawBase();
		coin.drawPoste();
		coin.drawViga();
		coin.drawHead();
		coin.drawBody();
		coin.drawPants();
		coin.drawRHand();
		coin.drawLHand();
		coin.drawRFeet();
		coin.drawLFeet();
	}
	
	function sprite (options) {
	
		var that = {},
			frameIndex = 0,
			tickCount = 0,
			ticksPerFrame = options.ticksPerFrame || 0,
			numberOfFrames = options.numberOfFrames || 1;
		
		that.context = options.context;
		that.width = options.width;
		that.height = options.height;
		that.image = options.image;

		
		that.update = function () {

            tickCount += 1;

            if (tickCount > ticksPerFrame) {

				tickCount = 0;
				
                // If the current frame index is in range
                if (frameIndex < numberOfFrames - 1) {	
                    // Go to the next frame
                    frameIndex += 1;
                } else {
                    frameIndex = 0;
                }
            }
        };
		
		that.drawPoste = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   90,
			   52,
			   100,
			   that.height,
			   0,
			   0,
			   100,
			   327);
		};
		
		that.drawHead = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   266,
			   5,
			   84,
			   88,
			   165,
			   0,
			   84,
			   88);
		};	

		that.drawBody = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   197,
			   238,
			   63,
			   66,
			   130,
			   61,
			   63,
			   66);
		};

		that.drawPants = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   266,
			   103,
			   79,
			   55,
			   119,
			   116,
			   79,
			   55);
		};

		that.drawRHand = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   5,
			   168,
			   39,
			   70,
			   173,
			   80,
			   39,
			   70);
		};
		
		that.drawLHand = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   261,
			   168,
			   40,
			   60,
			   105,
			   82,
			   40,
			   60);
		};		
		
		that.drawRFeet = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   197,
			   52,
			   59,
			   68,
			   160,
			   150,
			   59,
			   68);
		};		

		that.drawLFeet = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   197,
			   130,
			   54,
			   64,
			   104,
			   150,
			   54,
			   64);
		};			

		that.drawViga = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   5,
			   52,
			   75,
			   71,
			   97,
			   1,
			   75,
			   71);
		};		
		
		
		that.drawBase = function () {
		
			// Clear the canvas
			//that.context.clearRect(0, 0, that.width, that.height);
		  
			// Draw the animation
			that.context.drawImage(
			   that.image,
			   5,
			   5,
			   that.width,
			   that.height,
			   0,
			   220,
			   that.width,
			   that.height);
		};		
		
		return that;
	}
	
	// Get canvas
	canvas = document.getElementById("coinAnimation");
	canvas.width = 260;
	canvas.height = 260;
	
	// Create sprite sheet
	coinImage = new Image();	
	
	// Create sprite
	coin = sprite({
		context: canvas.getContext("2d"),
		width: 346,
		height: 320,
		image: coinImage,
		numberOfFrames: 10,
		ticksPerFrame: 4
	});
	
	// Load sprite sheet
	coinImage.addEventListener("load", gameLoop);
	coinImage.src = "images/spritesheet.png";

} ());

